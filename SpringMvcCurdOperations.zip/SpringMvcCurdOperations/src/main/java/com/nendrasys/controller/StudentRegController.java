package com.nendrasys.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nendrasys.models.StudentReg;
import com.nendrasys.services.StudentRegService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller("studentRegController")
@RequestMapping
public class StudentRegController<HttpSession> {
    @Autowired
    public StudentRegService studentRegService;

    @RequestMapping(value = "/student")
    public String showAllStudent(Model model){
        List<StudentReg> students = studentRegService.getAllStudents();
        model.addAttribute("listOfStudents",students);
        return "showStudent";
    }

    //this method return object type of data to json form in browser
    @ResponseBody
    @RequestMapping(value = "/studentJson",produces = {"application/json"})
    public String displayall(Map<String, Object> map, HttpSession session) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(studentRegService.getAllStudents());
    }

    @RequestMapping(value = "/insert",method = RequestMethod.GET)
    public String showHome(Model model){
        StudentReg reg = new StudentReg();
        model.addAttribute("reg",reg);
        return "register";
    }

    @RequestMapping(value = "/saveData" , method = RequestMethod.POST)
    public String saveStudentData(@ModelAttribute("reg") StudentReg reg , Model model){
        String resultMsg = null;
        resultMsg = studentRegService.saveStudentData(reg);
        model.addAttribute("result",resultMsg);
        return "show";
    }

    @RequestMapping(value = "/update/{id}",method = RequestMethod.GET)
    public String showHome1(Model model,@PathVariable(value = "id") int id){
        StudentReg reg = studentRegService.getStudentById(id);
        model.addAttribute("reg",reg);
        return "updateData";
    }

    @RequestMapping(value="/updateData", method = RequestMethod.POST)
    public String updateStudentData(@ModelAttribute("reg") StudentReg reg, Model model){
        String resultMsg = null;
        resultMsg=studentRegService.updateStudentData(reg);
        model.addAttribute("result",resultMsg);
        return "show1";
    }

    @RequestMapping("/deleteData/{id}")
    public String deleteStudentById(Model model, @PathVariable(value = "id") int id){
        model.addAttribute("getStudentById",studentRegService.deleteStudentData(id));
        return "delete";
    }

    @RequestMapping("/studentId/{id}")
     public String getStudentById(Model model, @PathVariable(value = "id") int id){
         model.addAttribute("getStudentById",studentRegService.getStudentById(id));
         return "student";
     }
    @ModelAttribute("countriesList")
    public List<String> countries(){
        List<String> list = new ArrayList<>();
        list.add("India");
        list.add("China");
        list.add("japan");
        list.add("malesiya");
        return  list;
    }
}

