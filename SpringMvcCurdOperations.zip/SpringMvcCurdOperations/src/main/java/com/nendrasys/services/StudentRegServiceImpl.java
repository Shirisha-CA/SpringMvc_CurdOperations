package com.nendrasys.services;

import com.nendrasys.daos.StudentRegDao;
import com.nendrasys.models.StudentReg;

import java.util.List;

public class StudentRegServiceImpl implements StudentRegService {
    StudentRegDao studentRegDao;

    public StudentRegDao getStudentRegDao() {
        return studentRegDao;
    }

    public void setStudentRegDao(StudentRegDao studentRegDao) {
        this.studentRegDao = studentRegDao;
    }

    @Override
    public List<StudentReg> getAllStudents() {
        return studentRegDao.getAllStudents();
    }

    @Override
    public String saveStudentData(StudentReg reg) {
       int count = 0;
       count= studentRegDao.saveStudentData(reg);
       if(count==1){
           return "Data is Inserted successfully";
       }
       else{
           return "Data is not Inserted";
       }
    }

    @Override
    public String updateStudentData(StudentReg reg) {
        int count=0;
        count=studentRegDao.updateStudentData(reg);
        if(count==1){
            return "Data is updated successfully";
        }
        else{
            return "Data is not updated";
        }
    }

    @Override
    public int deleteStudentData(int id) {
        return studentRegDao.deleteStudentData(id);
    }

    @Override
    public StudentReg getStudentById(int id) {
        return studentRegDao.getStudentById(id);
    }
}
