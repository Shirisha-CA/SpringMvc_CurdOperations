package com.nendrasys.services;

import com.nendrasys.models.StudentReg;

import java.util.List;

public interface StudentRegService {
     List<StudentReg> getAllStudents();
     String saveStudentData(StudentReg reg);
     String updateStudentData(StudentReg reg);
     int deleteStudentData(int id);
     StudentReg getStudentById(int id);
}
