package com.nendrasys.daos;

import com.nendrasys.models.StudentReg;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class StudentRegDaoImpl implements StudentRegDao {
    JdbcTemplate template;
    public JdbcTemplate getTemplate() {
        return template;
    }

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }
    @Override
    public List<StudentReg> getAllStudents() {
        List<StudentReg> list = template.query("SELECT * FROM studentreginfo", new RowMapper<StudentReg>() {
            @Override
            public StudentReg mapRow(ResultSet resultSet, int i) throws SQLException {
                StudentReg student = new StudentReg();
                student.setId(resultSet.getInt("id"));
                student.setName(resultSet.getString("name"));
                student.setAge(resultSet.getInt("age"));
                student.setCountry(resultSet.getString("country"));
                return student;
            }
        });
        return list;
    }

    @Override
    public int saveStudentData(StudentReg reg) {
        String query = "insert into studentreginfo(id,name,age,country) values('"+reg.getId()+"','"+reg.getName()+"','"+reg.getAge()+"','"+reg.getCountry()+"')";
        System.out.println("From dao:: "+ query);
        return template.update(query);
    }

    @Override
    public int updateStudentData(StudentReg reg) {
        String query = "update studentreginfo set name='"+reg.getName()+"',age='"+reg.getAge()+"',country='"+reg.getCountry()+"' where id='"+reg.getId()+"'";
        return template.update(query);
    }

    @Override
    public int deleteStudentData(int id) {
        String query = "delete from studentreginfo where id="+id+"";
        return template.update(query);
    }

    @Override
    public StudentReg getStudentById(int id) {
        StudentReg student = (StudentReg) template.queryForObject("SELECT * FROM studentreginfo where id=?", new BeanPropertyRowMapper(StudentReg.class), id);
        return student;
    }
}
