package com.nendrasys.daos;

import com.nendrasys.models.StudentReg;

import java.util.List;

public interface StudentRegDao {
    List<StudentReg> getAllStudents();
    public int saveStudentData(StudentReg reg);
    public int updateStudentData(StudentReg reg);
    public int deleteStudentData(int id);
    StudentReg getStudentById(int id);
}
